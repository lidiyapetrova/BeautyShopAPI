﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeautyShopAPI.DL.Migrations
{
    public partial class UpdatePrimaryKeys2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "CustomerId",
                keyValue: 1,
                column: "DateRegistered",
                value: new DateTime(2024, 3, 6, 14, 53, 46, 714, DateTimeKind.Local).AddTicks(6666));

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "CustomerId",
                keyValue: 2,
                column: "DateRegistered",
                value: new DateTime(2024, 3, 6, 14, 53, 46, 714, DateTimeKind.Local).AddTicks(6710));

            migrationBuilder.UpdateData(
                table: "Orders",
                keyColumn: "OrderId",
                keyValue: 1,
                column: "OrderDate",
                value: new DateTime(2024, 3, 6, 14, 53, 46, 714, DateTimeKind.Local).AddTicks(6919));

            migrationBuilder.UpdateData(
                table: "Orders",
                keyColumn: "OrderId",
                keyValue: 2,
                column: "OrderDate",
                value: new DateTime(2024, 3, 6, 14, 53, 46, 714, DateTimeKind.Local).AddTicks(6925));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 3, 6, 14, 53, 46, 714, DateTimeKind.Local).AddTicks(6886));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2024, 3, 6, 14, 53, 46, 714, DateTimeKind.Local).AddTicks(6893));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "CustomerId",
                keyValue: 1,
                column: "DateRegistered",
                value: new DateTime(2024, 3, 6, 14, 52, 1, 507, DateTimeKind.Local).AddTicks(1106));

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "CustomerId",
                keyValue: 2,
                column: "DateRegistered",
                value: new DateTime(2024, 3, 6, 14, 52, 1, 507, DateTimeKind.Local).AddTicks(1141));

            migrationBuilder.UpdateData(
                table: "Orders",
                keyColumn: "OrderId",
                keyValue: 1,
                column: "OrderDate",
                value: new DateTime(2024, 3, 6, 14, 52, 1, 507, DateTimeKind.Local).AddTicks(1268));

            migrationBuilder.UpdateData(
                table: "Orders",
                keyColumn: "OrderId",
                keyValue: 2,
                column: "OrderDate",
                value: new DateTime(2024, 3, 6, 14, 52, 1, 507, DateTimeKind.Local).AddTicks(1272));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2024, 3, 6, 14, 52, 1, 507, DateTimeKind.Local).AddTicks(1249));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2024, 3, 6, 14, 52, 1, 507, DateTimeKind.Local).AddTicks(1254));
        }
    }
}
