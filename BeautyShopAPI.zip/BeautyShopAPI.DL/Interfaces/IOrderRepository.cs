﻿using BeautyShopAPI.Models;

namespace BeautyShopAPI.DL.Interfaces
{
    public interface IOrderRepository
    {
        Order GetById(int id);
        IEnumerable<Order> GetAll();
        void Add(Order order);
        void Update(Order order);
        void Delete(int id);
    }
}
