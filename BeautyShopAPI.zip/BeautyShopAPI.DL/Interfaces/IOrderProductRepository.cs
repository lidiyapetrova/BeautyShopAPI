﻿using BeautyShopAPI.Models;

namespace BeautyShopAPI.DL.Interfaces
{
    public interface IOrderProductRepository
    {
        IEnumerable<OrderProduct> GetOrdersForCustomerId(int customerId);
        IEnumerable<Product> GetAllProductsForOrderId(int orderId);
    }
}
