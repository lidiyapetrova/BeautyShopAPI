﻿using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeautyShopAPI.DL.Repositories
{
    public class OrderProductRepository : IOrderProductRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<OrderProduct> GetOrdersForCustomerId(int customerId)
        {
            return _context.OrderProducts
                .Include(op => op.Order)
                .Include(op => op.Product)
                .Where(op => op.CustomerId == customerId)
                .ToList();
        }

        public IEnumerable<Product> GetAllProductsForOrderId(int orderId)
        {
            return _context.OrderProducts
                .Include(op => op.Product)
                .Where(op => op.OrderId == orderId)
                .Select(op => op.Product)
                .ToList();
        }
    }
}
