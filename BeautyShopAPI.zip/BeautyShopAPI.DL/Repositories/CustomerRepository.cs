﻿using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models;

namespace BeautyShopAPI.DL.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private ApplicationDbContext _context;

        public CustomerRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public Customer GetById(int id)
        {
            return _context.Customers.Find(id);
        }

        public IEnumerable<Customer> GetAll()
        {
            return _context.Customers.ToList();
        }

        public void Add(Customer customer)
        {
            _context.Customers.Add(customer);
            _context.SaveChanges();
        }

        public bool Update(Customer customer)
        {
            Customer? existingCustomer = _context.Customers
                .Find(customer.CustomerId);

            if (existingCustomer == null)
            {
                return false;
            }

            _context.Entry(existingCustomer).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            _context.Attach(customer);
            _context.Entry(customer).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
            return true;
        }

        public void Delete(int id)
        {
            var customer = _context.Customers.Find(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
                _context.SaveChanges();
            }
        }
    }
}
