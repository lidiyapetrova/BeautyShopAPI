﻿using BeautyShopAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace BeautyShopAPI.DL
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Customer>  Customers { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<Product> Products { get; set; }

        public DbSet<OrderProduct> OrderProducts { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) :
            base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); 

            modelBuilder.Entity<Customer>().HasData(
                new Customer
                {
                    CustomerId = 1,
                    FullName = "John Doe",
                    Email = "john@example.com",
                    PhoneNumber = "123456789",
                    Address = "123 Main St",
                    DateRegistered = DateTime.Now
                },
                new Customer
                {
                    CustomerId = 2,
                    FullName = "Jane Smith",
                    Email = "jane@example.com",
                    PhoneNumber = "987654321",
                    Address = "456 Elm St",
                    DateRegistered = DateTime.Now
                }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductId = 1,
                    Name = "Shampoo",
                    Description = "Moisturizing shampoo",
                    Price = 10.99,
                    ImageUrl = "shampoo.jpg", 
                    DateAdded = DateTime.Now
                },
                new Product
                {
                    ProductId = 2,
                    Name = "Conditioner",
                    Description = "Nourishing conditioner",
                    Price = 8.99,
                    ImageUrl = "conditioner.jpg", 
                    DateAdded = DateTime.Now
                }
            );

            modelBuilder.Entity<Order>().HasData(
                new Order
                {
                    OrderId = 1,
                    Quantity = 2,
                    TotalPrice = 25.98,
                    OrderDate = DateTime.Now,
                    ShippingAddress = "123 Main St",
                    Notes = "Please deliver during office hours"
                },
                new Order
                {
                    OrderId = 2,
                    Quantity = 1,
                    TotalPrice = 8.99,
                    OrderDate = DateTime.Now,
                    ShippingAddress = "456 Elm St",
                    Notes = "Fragile items, handle with care"
                }
            );

            modelBuilder.Entity<OrderProduct>().HasData(
                new OrderProduct { OrderProductId = 1,OrderId = 1, ProductId = 1, CustomerId = 1 },
                new OrderProduct { OrderProductId = 2, OrderId = 1, ProductId = 1, CustomerId = 2 },
                new OrderProduct { OrderProductId = 3, OrderId = 2, ProductId = 2, CustomerId = 1 }
            );
        }
    }
}
