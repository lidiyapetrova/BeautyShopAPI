﻿using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Models;
using BeautyShopAPI.Application.Interfaces;

namespace BeautyShopAPI.Application.Mappers
{
    public class CustomerMapper : ICustomerMapper
    {
        public CustomerDTO MapToDTO(Customer customer)
        {
            if (customer == null)
                return null;

            return new CustomerDTO
            {
                CustomerId = customer.CustomerId,
                FullName = customer.FullName,
                Email = customer.Email,
                PhoneNumber = customer.PhoneNumber,
                Address = customer.Address,
                DateRegistered = customer.DateRegistered
            };
        }

        public Customer MapToEntity(CustomerDTO customerDTO)
        {
            if (customerDTO == null)
                return null;

            return new Customer
            {
                CustomerId = customerDTO.CustomerId,
                FullName = customerDTO.FullName,
                Email = customerDTO.Email,
                PhoneNumber = customerDTO.PhoneNumber,
                Address = customerDTO.Address,
                DateRegistered = customerDTO.DateRegistered
            };
        }
    }
}
