﻿using BeautyShopAPI.Application.Interfaces;
using BeautyShopAPI.Models;
using BeautyShopAPI.Models.Dto;

namespace BeautyShopAPI.Application.Mappers
{
    public class OrderMapper : IOrderMapper
    {
        public OrderDTO MapToDTO(Order order)
        {
            if (order == null)
                return null;

            return new OrderDTO
            {
                OrderId = order.OrderId,
                Quantity = order.Quantity,
                TotalPrice = order.TotalPrice,
                OrderDate = order.OrderDate,
                Notes = order.Notes,
                ShippingAddress = order.ShippingAddress
            };
        }

        public Order MapToEntity(OrderDTO orderDTO)
        {
            if (orderDTO == null)
                return null;

            return new Order
            {
                OrderId = orderDTO.OrderId,
                Quantity = orderDTO.Quantity,
                TotalPrice = orderDTO.TotalPrice,
                OrderDate = orderDTO.OrderDate,
                Notes = orderDTO.Notes,
                ShippingAddress = orderDTO.ShippingAddress
            };
        }
    }
}
