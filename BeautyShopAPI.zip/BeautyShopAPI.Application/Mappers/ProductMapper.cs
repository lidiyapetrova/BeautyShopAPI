﻿using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Models;
using BeautyShopAPI.Application.Interfaces;

namespace BeautyShopAPI.Application.Mappers
{
    public class ProductMapper : IProductMapper
    {
        public ProductDTO MapToDTO(Product product)
        {
            if (product == null)
                return null;

            return new ProductDTO
            {
                ProductId = product.ProductId,
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                DateAdded = product.DateAdded
            };
        }

        public Product MapToEntity(ProductDTO productDTO)
        {
            if (productDTO == null)
                return null;

            return new Product
            {
                ProductId = productDTO.ProductId,
                Name = productDTO.Name,
                Description = productDTO.Description,
                Price = productDTO.Price,
                DateAdded = productDTO.DateAdded
            };
        }
    }
}
