﻿using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Models;

namespace BeautyShopAPI.Application.Interfaces
{
    public interface ICustomerMapper
    {
        CustomerDTO MapToDTO(Customer customer);
        Customer MapToEntity(CustomerDTO customerDTO);
    }
}
