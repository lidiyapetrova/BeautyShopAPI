﻿using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeautyShopAPI.Application.Interfaces
{
    public interface IOrderMapper
    {
        OrderDTO MapToDTO(Order order);
        Order MapToEntity(OrderDTO orderDTO);
    }
}
