﻿using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Models;

namespace BeautyShopAPI.Application.Interfaces
{
    public interface IProductMapper
    {
        ProductDTO MapToDTO(Product product);
        Product MapToEntity(ProductDTO productDTO);
    }
}
