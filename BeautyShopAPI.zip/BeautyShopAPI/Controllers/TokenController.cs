﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BeautyShopAPI.Controllers
{
    /// <summary>
    /// Controller for managing authentication tokens.
    /// </summary>
    [Route("api/token")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly UserCredentials defaultUser = new UserCredentials()
        {
            User = "user",
            Pass = "password"
        };

        private readonly IConfiguration _configuration;

        public TokenController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Generates a JWT token for authentication based on provided credentials.
        /// </summary>
        /// <param name="credentials">User credentials (username and password).</param>
        /// <returns>JWT token if authentication is successful; BadRequest if credentials are invalid.</returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult Post([FromBody] UserCredentials credentials)
        {
            if (defaultUser.Equals(credentials))
            {
                var claims = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                    new Claim("UserName", defaultUser.User),
                    new Claim("Password", defaultUser.Pass)
                };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                var token = new JwtSecurityToken(
                    _configuration["Jwt:Issuer"],
                    _configuration["Jwt:Audience"],
                    claims,
                    expires: DateTime.UtcNow.AddMinutes(30),
                    signingCredentials: signIn);

                return Ok(new JwtSecurityTokenHandler().WriteToken(token));
            }
            else
            {
                return BadRequest("Invalid username or password.");
            }
        }
    }

    /// <summary>
    /// Represents user credentials for authentication.
    /// </summary>
    public class UserCredentials
    {
        public string User { get; set; }
        public string Pass { get; set; }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (!(obj is UserCredentials))
            {
                return false;
            }

            UserCredentials other = (UserCredentials)obj;
            return this.User == other.User && this.Pass == other.Pass;
        }

        public override int GetHashCode()
        {
            return (User != null ? User.GetHashCode() : 0) ^ (Pass != null ? Pass.GetHashCode() : 0);
        }
    }
}
