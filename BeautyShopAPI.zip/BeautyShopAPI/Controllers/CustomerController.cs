﻿using BeautyShopAPI.Application.Mappers;
using BeautyShopAPI.BL.Interfaces;
using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BeautyShopAPI.Controllers
{
    /// <summary>
    /// Controller for managing customer data.
    /// </summary>
    [Authorize]
    [Route("api/customer")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private ICustomerService _customerService;

        private CustomerValidator _customerValidator;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerController"/> class.
        /// </summary>
        /// <param name="customerService">The customer service.</param>
        /// <param name="customerValidator">The customer validator.</param>
        public CustomerController(
            ICustomerService customerService,
            CustomerValidator customerValidator)
        {
            _customerService = customerService;
            _customerValidator = customerValidator;
        }

        /// <summary>
        /// Gets all customers.
        /// </summary>
        /// <returns>The list of customers.</returns>
        [HttpGet]
        public ActionResult Get()
        {
            var customers = _customerService.GetAllCustomers();
            return Ok(customers);
        }

        /// <summary>
        /// Gets a customer by ID.
        /// </summary>
        /// <param name="id">The customer ID.</param>
        /// <returns>The customer with the specified ID.</returns>
        [HttpGet("{id}")]
        public ActionResult Get(int id)
        {
            var customer = _customerService.GetCustomerById(id);
            if (customer == null)
            {
                return NotFound("Not found");
            }
            return Ok(customer);
        }

        /// <summary>
        /// Adds a new customer.
        /// </summary>
        /// <param name="customerDto">The customer DTO.</param>
        /// <returns>The action result.</returns>
        [HttpPost]
        public ActionResult Post([FromBody] CustomerDTO customerDto)
        {
            var validationResult = _customerValidator
                .Validate(new CustomerMapper().MapToEntity(customerDto));

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors);
            }

            try
            {
                _customerService.AddCustomer(customerDto);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Updates an existing customer.
        /// </summary>
        /// <param name="id">The ID of the customer to update.</param>
        /// <param name="customerDto">The updated customer data.</param>
        /// <returns>The action result.</returns>
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] CustomerDTO customerDto)
        {
            var foundUser = _customerService.GetCustomerById(id);

            if (foundUser == null)
            {
                return NotFound();
            }

            try
            {
                _customerService.UpdateCustomer(customerDto);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Deletes a customer by ID.
        /// </summary>
        /// <param name="id">The ID of the customer to delete.</param>
        /// <returns>The action result.</returns>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _customerService.DeleteCustomer(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        /// <summary>
        /// Gets all customers with pagination and filtering support.
        /// </summary>
        /// <param name="page">The page number.</param>
        /// <param name="pageSize">The page size.</param>
        /// <param name="filter">The filter criteria.</param>
        /// <returns>The paginated list of customers.</returns>
        [HttpGet("p")]
        public IActionResult GetAll(
            [FromQuery] int page = 1, 
            [FromQuery] int pageSize = 2,            
            [FromQuery] string filter = "")
        {
            var query = _customerService.GetAllCustomers().AsQueryable();

            if (!string.IsNullOrEmpty(filter))
            {
                query = query.Where(customer => customer.FullName.Contains(filter));
            }

            var totalCount = query.Count();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            query = query.Skip((page - 1) * pageSize).Take(pageSize);

            var result = new
            {
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page,
                PageSize = pageSize,
                Customers = query.ToList()
            };

            return Ok(result);
        }
    }
}
