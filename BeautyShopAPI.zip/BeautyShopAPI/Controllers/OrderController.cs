﻿using BeautyShopAPI.Application.Mappers;
using BeautyShopAPI.BL.Interfaces;
using BeautyShopAPI.BL.Services;
using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Validators;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BeautyShopAPI.Controllers
{
    /// <summary>
    /// Controller for managing orders.
    /// </summary>
    [Route("api/order")]
    [Authorize]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        private readonly OrderValidator _orderValidator;

        public OrderController(
            IOrderService orderService, 
            OrderValidator orderValidator)
        {
            _orderService = orderService;
            _orderValidator = orderValidator;
        }

        /// <summary>
        /// Retrieves all orders.
        /// </summary>
        [HttpGet]
        public ActionResult Get()
        {
            var orders = _orderService.GetAll();
            return Ok(orders);
        }

        /// <summary>
        /// Retrieves a specific order by ID.
        /// </summary>
        /// <param name="id">The ID of the order to retrieve.</param>
        [HttpGet("{id}")]
        public ActionResult Get(int id)
        {
            var order = _orderService.GetById(id);
            if (order == null)
            {
                return NotFound("Order not found");
            }
            return Ok(order);
        }

        /// <summary>
        /// Creates a new order.
        /// </summary>
        /// <param name="orderDto">The data for the new order.</param>
        [HttpPost]
        public ActionResult Post([FromBody] OrderDTO orderDto)
        {
            var validationResult = _orderValidator
                .Validate(new OrderMapper().MapToEntity(orderDto));

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.Select(error => error.ErrorMessage));
            }

            try
            {
                // Map DTO to entity before passing to service
                var order = new OrderMapper().MapToEntity(orderDto);
                _orderService.Add(order);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Updates an existing order.
        /// </summary>
        /// <param name="id">The ID of the order to update.</param>
        /// <param name="orderDto">The updated data for the order.</param>
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] OrderDTO orderDto)
        {
            var foundOrder = _orderService.GetById(id);

            if (foundOrder == null)
            {
                return NotFound("Order not found");
            }

            var validationResult = _orderValidator
                .Validate(new OrderMapper().MapToEntity(orderDto));

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors.Select(error => error.ErrorMessage));
            }

            try
            {
                // Map DTO to entity before passing to service
                var order = new OrderMapper().MapToEntity(orderDto);
                _orderService.Update(order);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Deletes an existing order.
        /// </summary>
        /// <param name="id">The ID of the order to delete.</param>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _orderService.Delete(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves all orders with pagination and filtering support.
        /// </summary>
        /// <param name="page">The page number.</param>
        /// <param name="pageSize">The size of each page.</param>
        /// <param name="filter">The filter criteria.</param>
        [HttpGet("p")]
        public IActionResult GetAll(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 2,
            [FromQuery] string filter = "")
        {
            var query = _orderService.GetAll().AsQueryable();

            if (!string.IsNullOrEmpty(filter))
            {
                query = query.Where(customer => customer.ShippingAddress.Contains(filter));
            }

            var totalCount = query.Count();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            query = query.Skip((page - 1) * pageSize).Take(pageSize);

            var result = new
            {
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page,
                PageSize = pageSize,
                Orders = query.ToList()
            };

            return Ok(result);
        }
    }
}
