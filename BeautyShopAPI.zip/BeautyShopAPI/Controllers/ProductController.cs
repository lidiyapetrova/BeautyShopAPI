﻿using BeautyShopAPI.Application.Mappers;
using BeautyShopAPI.BL.Interfaces;
using BeautyShopAPI.BL.Services;
using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BeautyShopAPI.Controllers
{
    [Authorize]
    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        private readonly ProductValidator _productValidator;

        public ProductController(
            IProductService productService,
            ProductValidator productValidator)
        {
            _productService = productService;
            _productValidator = productValidator;
        }

        /// <summary>
        /// Retrieves all products.
        /// </summary>
        [HttpGet]
        public ActionResult GetAll()
        {
            var products = _productService.GetAll();
            return Ok(products);
        }

        /// <summary>
        /// Retrieves paginated list of products with optional filtering.
        /// </summary>
        /// <param name="page">The page number to retrieve. Default is 1.</param>
        /// <param name="pageSize">The number of products per page. Default is 2.</param>
        /// <param name="filter">The filter string to apply to product names.</param>
        /// <returns>An ActionResult containing the paginated list of products.</returns>
        [HttpGet("p")]
        public IActionResult GetAll(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 2,
            [FromQuery] string filter = "")
        {
            var query = _productService.GetAll().AsQueryable();

            if (!string.IsNullOrEmpty(filter))
            {
                query = query.Where(customer => customer.Name.Contains(filter));
            }

            var totalCount = query.Count();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            query = query.Skip((page - 1) * pageSize).Take(pageSize);

            var result = new
            {
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page,
                PageSize = pageSize,
                Products = query.ToList()
            };

            return Ok(result);
        }

        /// <summary>
        /// Retrieves a product by its ID.
        /// </summary>
        /// <param name="id">The ID of the product to retrieve.</param>
        [HttpGet("{id}")]
        public ActionResult Get(int id)
        {
            var product = _productService.GetById(id);
            if (product == null)
            {
                return NotFound("Product not found");
            }
            return Ok(product);
        }

        /// <summary>
        /// Adds a new product.
        /// </summary>
        /// <param name="productDto">The product data to add.</param>
        [HttpPost]
        public ActionResult Post([FromBody] ProductDTO productDto)
        {
            var validationResult = _productValidator
                .Validate(new ProductMapper().MapToEntity(productDto));

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors);
            }

            try
            {
                var product = new ProductMapper().MapToEntity(productDto);
                _productService.Add(product);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Updates an existing product.
        /// </summary>
        /// <param name="id">The ID of the product to update.</param>
        /// <param name="productDto">The updated product data.</param>
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] ProductDTO productDto)
        {
            var foundProduct = _productService.GetById(id);

            if (foundProduct == null)
            {
                return NotFound();
            }

            var validationResult = _productValidator
                .Validate(
                new ProductMapper()
                .MapToEntity(productDto));

            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors);
            }

            try
            {
                var product = new ProductMapper().MapToEntity(productDto);
                _productService.Update(product);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Deletes a product by its ID.
        /// </summary>
        /// <param name="id">The ID of the product to delete.</param>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _productService.Delete(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
