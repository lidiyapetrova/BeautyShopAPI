﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeautyShopAPI.Migrations
{
    public partial class SeedData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "CustomerId", "Address", "DateRegistered", "Email", "FullName", "PhoneNumber" },
                values: new object[,]
                {
                    { 1, "123 Main St", new DateTime(2024, 3, 5, 18, 35, 25, 198, DateTimeKind.Local).AddTicks(6161), "john@example.com", "John Doe", "123456789" },
                    { 2, "456 Elm St", new DateTime(2024, 3, 5, 18, 35, 25, 198, DateTimeKind.Local).AddTicks(6195), "jane@example.com", "Jane Smith", "987654321" }
                });

            migrationBuilder.InsertData(
                table: "Orders",
                columns: new[] { "OrderId", "Notes", "OrderDate", "Quantity", "ShippingAddress", "TotalPrice" },
                values: new object[,]
                {
                    { 1, "Please deliver during office hours", new DateTime(2024, 3, 5, 18, 35, 25, 198, DateTimeKind.Local).AddTicks(6312), 2, "123 Main St", 25.98 },
                    { 2, "Fragile items, handle with care", new DateTime(2024, 3, 5, 18, 35, 25, 198, DateTimeKind.Local).AddTicks(6315), 1, "456 Elm St", 8.9900000000000002 }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "DateAdded", "Description", "ImageUrl", "Name", "Price" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 3, 5, 18, 35, 25, 198, DateTimeKind.Local).AddTicks(6291), "Moisturizing shampoo", "shampoo.jpg", "Shampoo", 10.99 },
                    { 2, new DateTime(2024, 3, 5, 18, 35, 25, 198, DateTimeKind.Local).AddTicks(6297), "Nourishing conditioner", "conditioner.jpg", "Conditioner", 8.9900000000000002 }
                });

            migrationBuilder.InsertData(
                table: "OrderProducts",
                columns: new[] { "OrderProductId", "CustomerId", "OrderId", "ProductId" },
                values: new object[] { 1, 1, 1, 1 });

            migrationBuilder.InsertData(
                table: "OrderProducts",
                columns: new[] { "OrderProductId", "CustomerId", "OrderId", "ProductId" },
                values: new object[] { 2, 2, 1, 1 });

            migrationBuilder.InsertData(
                table: "OrderProducts",
                columns: new[] { "OrderProductId", "CustomerId", "OrderId", "ProductId" },
                values: new object[] { 3, 1, 2, 2 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "OrderProducts",
                keyColumn: "OrderProductId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "OrderProducts",
                keyColumn: "OrderProductId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "OrderProducts",
                keyColumn: "OrderProductId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "CustomerId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "CustomerId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Orders",
                keyColumn: "OrderId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Orders",
                keyColumn: "OrderId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2);
        }
    }
}
