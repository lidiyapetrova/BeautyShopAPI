﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeautyShopAPI.Migrations
{
    public partial class AddCustomerRelationship : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CustomerId",
                table: "OrderProducts",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_OrderProducts_CustomerId",
                table: "OrderProducts",
                column: "CustomerId");

            migrationBuilder.AddForeignKey(
                name: "FK_OrderProducts_Customers_CustomerId",
                table: "OrderProducts",
                column: "CustomerId",
                principalTable: "Customers",
                principalColumn: "CustomerId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrderProducts_Customers_CustomerId",
                table: "OrderProducts");

            migrationBuilder.DropIndex(
                name: "IX_OrderProducts_CustomerId",
                table: "OrderProducts");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "OrderProducts");
        }
    }
}
