﻿using BeautyShopAPI.Models;
using FluentValidation;

namespace BeautyShopAPI.Validators
{
    public class CustomerValidator : AbstractValidator<Customer>
    {
        public CustomerValidator()
        {
            RuleFor(customer => customer.FullName)
                .NotEmpty().WithMessage("Full name is required.")
                .MaximumLength(100).WithMessage("Full name cannot exceed 100 characters.");

            RuleFor(customer => customer.Email)
                .NotEmpty().WithMessage("Email is required.")
                .MaximumLength(100).WithMessage("Email cannot exceed 100 characters.")
                .EmailAddress().WithMessage("Invalid email format.");

            RuleFor(customer => customer.PhoneNumber)
                .NotEmpty().WithMessage("Phone number is required.")
                .MaximumLength(100).WithMessage("Phone number cannot exceed 100 characters.");

            RuleFor(customer => customer.Address)
                .NotEmpty().WithMessage("Address is required.")
                .MaximumLength(100).WithMessage("Address cannot exceed 100 characters.");

            RuleFor(customer => customer.DateRegistered)
                .NotEmpty().WithMessage("Date registered is required.");
        }
    }
}
