﻿using BeautyShopAPI.Models;
using FluentValidation;

namespace BeautyShopAPI.Validators
{
    public class ProductValidator : AbstractValidator<Product>
    {
        public ProductValidator()
        {
            RuleFor(product => product.Name)
                .NotEmpty().WithMessage("Product name is required")
                .MaximumLength(100).WithMessage("Product name must not exceed 100 characters");

            RuleFor(product => product.Description)
                .MaximumLength(200).WithMessage("Description must not exceed 200 characters");

            RuleFor(product => product.Price)
                .NotEmpty().WithMessage("Price is required")
                .GreaterThan(0).WithMessage("Price must be greater than zero");

            RuleFor(product => product.ImageUrl)
                .MaximumLength(500).WithMessage("Image URL must not exceed 500 characters");
        }
    }
}
