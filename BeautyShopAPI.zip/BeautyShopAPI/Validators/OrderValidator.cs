﻿using BeautyShopAPI.Models;
using FluentValidation;

namespace BeautyShopAPI.Validators
{
    public class OrderValidator : AbstractValidator<Order>
    {
        public OrderValidator()
        {
            RuleFor(order => order.Quantity)
                .GreaterThan(0)
                .WithMessage("Quantity must be greater than 0.");

            RuleFor(order => order.TotalPrice)
                .GreaterThan(0)
                .WithMessage("Total price must be greater than 0.");

            RuleFor(order => order.ShippingAddress)
                .NotEmpty()
                .WithMessage("Shipping address is required.")
                .MaximumLength(500)
                .WithMessage("Shipping address cannot exceed 500 characters.");

            RuleFor(order => order.Notes)
                .MaximumLength(500)
                .WithMessage("Notes cannot exceed 500 characters.");
        }
    }
}
