using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using BeautyShopAPI.BL.Services;
using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models;
using BeautyShopAPI.Models.Dto;
using BeautyShopAPI.Application.Mappers;

namespace BeautyShopAPI.Tests
{
    public class CustomerServiceTests
    {
        [Fact]
        public void GetAllCustomers_ReturnsAllCustomers()
        {
            var customers = new List<Customer>
            {
                new Customer { CustomerId = 1, FullName = "John Doe", Email = "john@example.com" },
                new Customer { CustomerId = 2, FullName = "Jane Smith", Email = "jane@example.com" }
            };

            var mockRepository = new Mock<ICustomerRepository>();
            mockRepository.Setup(repo => repo.GetAll()).Returns(customers);

            var customerService = new CustomerService(mockRepository.Object, new CustomerMapper());

            var result = customerService.GetAllCustomers();

            Assert.Equal(customers.Count, result.Count());
        }

        [Fact]
        public void GetCustomerById_ExistingId_ReturnsCustomer()
        {
            var customerId = 1;
            var customer = new Customer { CustomerId = customerId, FullName = "John Doe", Email = "john@example.com" };

            var mockRepository = new Mock<ICustomerRepository>();
            mockRepository.Setup(repo => repo.GetById(customerId)).Returns(customer);

            var customerService = new CustomerService(mockRepository.Object, new CustomerMapper());

            var result = customerService.GetCustomerById(customerId);

            Assert.NotNull(result);
            Assert.Equal(customerId, result.CustomerId);
        }

        [Fact]
        public void AddCustomer_ValidCustomer_AddsSuccessfully()
        {
            var customerDto = new CustomerDTO { FullName = "John Doe", Email = "john@example.com" };
            var customerToAdd = new Customer { FullName = customerDto.FullName, Email = customerDto.Email };

            var mockRepository = new Mock<ICustomerRepository>();
            mockRepository.Setup(repo => repo.Add(It.IsAny<Customer>())).Verifiable();

            var customerService = new CustomerService(mockRepository.Object, new CustomerMapper());

            customerService.AddCustomer(customerDto);
            mockRepository.Verify(repo => repo.Add(It.IsAny<Customer>()), Times.Once);
        }
    }
}
