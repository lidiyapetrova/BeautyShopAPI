﻿using Moq;
using BeautyShopAPI.BL.Services;
using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models;

namespace BeautyShopAPI.Tests
{
    public class OrderServiceTests
    {
        [Fact]
        public void GetById_ExistingId_ReturnsOrder()
        {
            // Arrange
            int orderId = 1;
            var order = new Order
            {
                OrderId = 1,
                Quantity = 2,
                TotalPrice = 50.0,
                OrderDate = DateTime.Now,
                ShippingAddress = "123 Main St, City, Country",
                Notes = "Handle with care"
            };

            var mockRepository = new Mock<IOrderRepository>();
            mockRepository.Setup(repo => repo.GetById(orderId)).Returns(order);

            var orderService = new OrderService(mockRepository.Object);
            var result = orderService.GetById(orderId);
            Assert.NotNull(result);
            Assert.Equal(orderId, result.OrderId);
        }

        [Fact]
        public void GetAll_ReturnsAllOrders()
        {
            List<Order> orders = new List<Order>
            {
                new Order
                {
                    OrderId = 1,
                    Quantity = 2,
                    TotalPrice = 50.0,
                    OrderDate = DateTime.Now,
                    ShippingAddress = "123 Main St, City, Country",
                    Notes = "Handle with care"
                },
                new Order
                {
                    OrderId = 2,
                    Quantity = 3,
                    TotalPrice = 75.0,
                    OrderDate = DateTime.Now.AddDays(-1),
                    ShippingAddress = "456 Oak St, Town, Country",
                    Notes = "Fragile items inside"
                }
            };

            var mockRepository = new Mock<IOrderRepository>();
            mockRepository.Setup(repo => repo.GetAll()).Returns(orders);

            var orderService = new OrderService(mockRepository.Object);
            var result = orderService.GetAll();
            Assert.Equal(orders.Count, result.Count());
        }
    }
}
