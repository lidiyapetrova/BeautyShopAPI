﻿using BeautyShopAPI.BL.Services;
using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models;
using Moq;

namespace BeautyShopAPI.Tests
{
    public class ProductServiceTests
    {
        [Fact]
        public void GetById_Returns_Product()
        {
            int productId = 1;
            var productRepositoryMock = new Mock<IProductRepository>();
            var expectedProduct = new Product { ProductId = productId, Name = "Product 1", Price = 50.0 };
            productRepositoryMock.Setup(repo => repo.GetById(productId)).Returns(expectedProduct);
            var productService = new ProductService(productRepositoryMock.Object);
            var result = productService.GetById(productId);
            Assert.Equal(expectedProduct, result);
        }

        [Fact]
        public void GetAll_Returns_AllProducts()
        {
            var products = new List<Product>
            {
                 new Product
                {
                    ProductId = 1,
                    Name = "Product 1",
                    Description = "Description for Product 1",
                    Price = 50.0,
                    ImageUrl = "https://example.com/image1.jpg",
                    DateAdded = DateTime.Now
                },
                new Product
                {
                    ProductId = 2,
                    Name = "Product 2",
                    Description = "Description for Product 2",
                    Price = 75.0,
                    ImageUrl = "https://example.com/image2.jpg",
                    DateAdded = DateTime.Now.AddMinutes(1)
                }
            };
            var productRepositoryMock = new Mock<IProductRepository>();
            productRepositoryMock.Setup(repo => repo.GetAll()).Returns(products);
            var productService = new ProductService(productRepositoryMock.Object);

            var result = productService.GetAll();
            Assert.Equal(products, result);
        }
    }
}
