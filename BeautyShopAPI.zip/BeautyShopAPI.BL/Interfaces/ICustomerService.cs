﻿using BeautyShopAPI.Models.Dto;

namespace BeautyShopAPI.BL.Interfaces
{
    public interface ICustomerService
    {
        IEnumerable<CustomerDTO> GetAllCustomers();
        CustomerDTO GetCustomerById(int id);
        void AddCustomer(CustomerDTO customerDTO);
        bool UpdateCustomer(CustomerDTO customerDTO);
        void DeleteCustomer(int id);
    }
}
