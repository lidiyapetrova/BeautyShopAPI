﻿using BeautyShopAPI.BL.Interfaces;
using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeautyShopAPI.BL.Services
{
    public class OrderProductService : IOrderProductService
    {
        private readonly IOrderProductRepository _orderProductRepository;

        public OrderProductService(IOrderProductRepository orderProductRepository)
        {
            _orderProductRepository = orderProductRepository;
        }

        public IEnumerable<OrderProduct> GetOrdersForCustomerId(int customerId)
        {
            return _orderProductRepository.GetOrdersForCustomerId(customerId);
        }

        public IEnumerable<Product> GetAllProductsForOrderId(int orderId)
        {
            return _orderProductRepository.GetAllProductsForOrderId(orderId);
        }
    }
}
