﻿using BeautyShopAPI.Application.Interfaces;
using BeautyShopAPI.BL.Interfaces;
using BeautyShopAPI.DL.Interfaces;
using BeautyShopAPI.Models.Dto;

namespace BeautyShopAPI.BL.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;

        private readonly ICustomerMapper _customerMapper;

        public CustomerService(
            ICustomerRepository customerRepository,
            ICustomerMapper customerMapper)
        {
            _customerRepository = customerRepository;
            _customerMapper = customerMapper;
        }

        public IEnumerable<CustomerDTO> GetAllCustomers()
        {
            var customers = _customerRepository.GetAll();
            return customers.Select(customer => _customerMapper.MapToDTO(customer));
        }

        public CustomerDTO GetCustomerById(int id)
        {
            var customer = _customerRepository.GetById(id);
            return _customerMapper.MapToDTO(customer);
        }

        public void AddCustomer(CustomerDTO customerDTO)
        {
            var customer = _customerMapper.MapToEntity(customerDTO);
            _customerRepository.Add(customer);            
        }

        public bool UpdateCustomer(CustomerDTO customerDTO)
        {
            var customer = _customerMapper.MapToEntity(customerDTO);
            return _customerRepository.Update(customer);
        }

        public void DeleteCustomer(int id)
        {
            _customerRepository.Delete(id);
        }
    }
}
