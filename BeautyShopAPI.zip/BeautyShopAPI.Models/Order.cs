﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BeautyShopAPI.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Required]
        public int Quantity { get; set; }

        public double TotalPrice { get; set; }        

        public DateTime OrderDate { get; set; }

        [Required]
        [MaxLength(500)]
        public string ShippingAddress { get; set; }

        [MaxLength(500)]
        public string Notes { get; set; }

        public List<OrderProduct> OrderProducts { get; set; } = new List<OrderProduct> { };

    }
}
