﻿namespace BeautyShopAPI.Models.Dto
{
    public class OrderDTO
    {
        public int OrderId { get; set; }
        public int Quantity { get; set; }
        public double TotalPrice { get; set; }
        public string ShippingAddress { get; set; }
        public string Notes { get; set; }
        public DateTime OrderDate { get; set; }
    }
}
